/** 
Description : 

@author Eric L SHU 
@date ${YEAR}-${MONTH}-${DAY} ${TIME}
@since JDK 1.8
*/